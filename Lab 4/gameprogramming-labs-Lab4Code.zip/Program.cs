﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab4
{
    class Program
    {
        static void Main(string[] args)
        {
            // create a new deck and print the contents of the deck

            // shuffle the deck and print the contents of the deck

            // take the top card from the deck and print the card rank and suit

            // take the top card from the deck and print the card rank and suit


        }
    }
}
