﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Lab4
{
    /// <summary>
    /// An enumeration for card suits
    /// </summary>
    public enum Suit
    {
        Clubs,
        Diamonds,
        Hearts,
        Spades
    }
}
